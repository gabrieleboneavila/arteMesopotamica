<div class="mt-5  title-white-normal">
      Vídeo
    </div>
    <div class="mt-1 ling subtitle-white-normal">
      Idioma <img src=<?=$ling?>>
    </div>
    <div class=" mt-4 video">
      <iframe width="560" height="315" src=<?php echo $vide?> frameborder="0"
        allow="accelerometer; autoplay; encrypted-media; " allowfullscreen></iframe>
    </div>