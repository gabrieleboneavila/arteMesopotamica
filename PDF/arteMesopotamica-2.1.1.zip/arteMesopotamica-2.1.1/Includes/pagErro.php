<style>
  @import url('https://fonts.googleapis.com/css?family=Montserrat:600&display=swap');

  *{
    padding: 0;
    margin: 0;
    font-family: 'Montserrat', sans-serif;
  }
  
  
  #div{
    display: flex;
    justify-content: center;
    align-items: center;
    background-color:#ffcdab;
    height: 100%;
    color:#5d5d5a;
    flex-direction:column
  
  }
  a{
    text-decoration:none
  }
</style>
<title>ERRO</title>
<div id="div"> <div>Nível não encontrado :( </div><div> Por favor escolha outro nível, </div><a href=<?php echo $pag?>> Clicando aqui</a></div>